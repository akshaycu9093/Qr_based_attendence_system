# QR-Based-Attendance-System
QR Based attendance system with React and android studio at the frontend and django and firebase at the backend.
