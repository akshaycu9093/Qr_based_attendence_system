public class Continuos {
}
