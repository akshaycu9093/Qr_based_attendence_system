

export default function AssignCredentials(){
  return
}