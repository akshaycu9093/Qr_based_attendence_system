export default function GenReport() {
  return <div></div>;
}
