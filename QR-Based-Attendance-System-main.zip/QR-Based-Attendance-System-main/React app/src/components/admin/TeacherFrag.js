export default function TeacherFrag(prop) {
  return <div></div>;
}
